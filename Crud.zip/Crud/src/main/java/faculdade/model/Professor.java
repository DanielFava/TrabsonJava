package faculdade.model;

public class Professor extends Pessoa {

	private static final long serialVersionUID = 1L;

}
