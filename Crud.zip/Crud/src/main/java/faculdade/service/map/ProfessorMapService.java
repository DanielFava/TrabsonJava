package faculdade.service.map;

import java.util.Set;
import faculdade.model.Professor ;
import faculdade.service.ProfessorService;

public class ProfessorMapService extends AbstractMapService<Professor, Long> implements ProfessorService {
	
	@Override
	public Set<Professor> getAll() {
		return super.findAll();
	}

	@Override
	public Professor save(Professor professor) {
		return super.save(professor);
	}

	@Override
	public Professor findById(Long id) {
		return super.findById(id);
	}

	@Override
	public void delete(Professor professor) {
		
	}

	@Override
	public void deleteById(Long id) {
		
	}

	@Override
	public Professor findByName(String nome) {
		return null;
	}

	@Override
	public Professor findBySobreNome(String sobreNome) {
		return null;
	}

	@Override
	public void update(Professor object) {
		
	}

	@Override
	public void updateById(Long id) {
		
	}
	

}
