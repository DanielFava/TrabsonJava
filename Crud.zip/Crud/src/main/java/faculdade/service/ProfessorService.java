package faculdade.service;

import faculdade.model.Professor;
import faculdade.service.crud.CrudService;

public interface ProfessorService extends CrudService<Professor, Long>{
	Professor findByName(String nome);
	Professor findBySobreNome(String sobreNome);
}
