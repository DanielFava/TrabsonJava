package faculdade.bootstrap;

public class DataLoader {

}
