package faculdade.controller;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import faculdade.model.Professor;
import faculdade.service.map.ProfessorMapService;

@RestController
@RequestMapping(path = "/professor")
public class ProfessorController {
	
	@Autowired
	ProfessorMapService professorMapService;

	@RequestMapping
	public Set<Professor> getAll(){
		return professorMapService.getAll();
	}
	
	@RequestMapping(path = "{/id}", method = RequestMethod.GET) //Traz os Dados com base no ID 	
	public Professor getAlunoById(@PathVariable Long id) {
		return professorMapService.findById(id);
	}
	
	@RequestMapping(method = RequestMethod.DELETE)
	public void deleteProfessor(@RequestBody Professor professor) {
		professorMapService.delete(professor);
	}

	@RequestMapping(path = "{/id}", method = RequestMethod.DELETE) //Execulta o Delete com base no ID
	public void deleteAlunoById(@PathVariable Long id) {
		professorMapService.deleteById(id);
	}
	
	@RequestMapping(method = RequestMethod.PUT) 
	public void updateProfessor(@RequestBody Professor professor) {
		professorMapService.update(professor);
	}
	@RequestMapping(path = "{/id}", method = RequestMethod.PUT) //Execulta o Update com base no ID
	public void updateProfessor(@PathVariable Long id) {
		professorMapService.updateById(id);
	}
}
